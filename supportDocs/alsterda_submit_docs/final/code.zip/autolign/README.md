# autolign

## contributors
- John Alsterda, alsterda@stanford.edu
- Junwu Zhang, junwuz@stanford.edu
- Masanori Ogihara, ogihara@stanford.edu
- Jorge Cordero, icoen@stanford.edu

## getting started
- The code runs using the Ubuntu terminal command /scripts/autolign.py
- Specify simulation or experiment using a command line tag
- Specift learning algorithm by commenting in/out appropriate lines 
